## Objetivo

Portfolio personal de Luna Galilea como sitio estático multi-página, responsive, con sistema de diseño Material Design 3 (esquema claro) basado en los tokens de Figma que pasaste, tipografías Playfair Display + Open Sans desde Google Fonts, e íconos de Material Symbols. El proyecto ya está montado en TanStack Start (React + Vite + Tailwind v4), que se sube a GitHub como cualquier repo Node.

## Estructura de rutas

- `/` — Landing (replica fiel del PDF: hero + Featured Work con 3 proyectos)
- `/about` — Bio, skills, experiencia
- `/contact` — Email + redes (links externos)

Cada ruta con su propio `head()` (title, description, og:*).

Los "VIEW CASE STUDY" de los 3 proyectos serán enlaces externos (`<a target="_blank">`) a URLs que después me pases — por ahora quedan como `#` con `TODO` visible para que los cambies fácil.

## Sistema de diseño (MD3 light)

Mapeo de los tokens MD3 de tu JSON a variables CSS en `src/styles.css` y a utilidades Tailwind v4 vía `@theme inline`. Tokens clave:

- `--md-primary: #8C4A60`, `--md-on-primary: #FFFFFF`
- `--md-primary-container: #FFD9E2`, `--md-on-primary-container: #703349`
- `--md-secondary: #74565F`, `--md-tertiary: #7C5635`
- `--md-background / --md-surface: #FFF8F8`, `--md-on-surface: #22191C`
- `--md-surface-container-low/high/highest`, `--md-surface-variant: #F2DDE2`
- `--md-outline: #837377`, `--md-outline-variant: #D5C2C6`
- `--md-error: #BA1A1A`, contenedores e inverse incluidos
- Mapeo a los semánticos que Tailwind usa (`--background`, `--foreground`, `--primary`, `--card`, `--muted`, etc.) para que los componentes shadcn existentes hereden el tema sin romperse.

Dejo la estructura preparada para agregar `.dark { … }` con el otro JSON cuando me lo pases — solo será pegar valores.

## Tipografías e íconos

- Carga en `__root.tsx` con `<link>` a Google Fonts: Playfair Display (400/700/italic) y Open Sans (400/600).
- Material Symbols Outlined para íconos puntuales (flecha en "VIEW CASE STUDY", redes en contacto).
- En `@theme inline`: `--font-display: 'Playfair Display', serif;` y `--font-sans: 'Open Sans', sans-serif;` → utilidades `font-display` y `font-sans`.

## Componentes a crear

```
src/components/
  SiteHeader.tsx        nav minimal con links a /, /about, /contact
  SiteFooter.tsx        nombre + redes + año
  Hero.tsx              título Playfair + párrafo con énfasis itálicos + imagen
  FeaturedWork.tsx      label "* FEATURED WORK *"
  ProjectCard.tsx       tarjeta rosa con título, descripción, link, imagen; prop `reverse` para alternar
src/routes/
  index.tsx             hero + featured work (3 ProjectCard)
  about.tsx
  contact.tsx
  __root.tsx            agrega header/footer + fuentes
```

## Responsive

- Mobile-first. Tarjetas: imagen arriba, texto abajo (`flex-col`). Desktop ≥ md: dos columnas con alternancia (`md:flex-row` / `md:flex-row-reverse`).
- Hero: stack en mobile, dos columnas en desktop.
- Container: `max-w-6xl mx-auto px-6`.

## Imágenes

- Personaje "binoculars" del hero: lo recorto del PDF que subiste y lo guardo en `src/assets/hero-character.png`.
- Para los 3 mockups de proyecto: genero placeholders neutros en tonos del tema (`src/assets/smart-project.jpg`, etc.) hasta que me pases las imágenes reales.

## Para subir a GitHub

El proyecto ya es un repo Node estándar. Te dejo:

- `README.md` con instrucciones (`bun install`, `bun dev`, `bun run build`).
- `.gitignore` ya está configurado.
- Después solo: `git init && git remote add origin … && git push`. No requiere config extra.

## Detalles técnicos

- Tailwind v4: tokens en `@theme inline` dentro de `src/styles.css`, valores reales en `:root`.
- Sin modo oscuro activo aún; estructura lista para `.dark { … }`.
- TanStack Router file-based: cada nueva ruta es un archivo en `src/routes/`.
- SEO: title/description únicos por ruta vía `head()`.

## Fuera de alcance (siguiente iteración)

- Dark mode (espero tu `Dark.tokens.json`).
- URLs reales de los case studies.
- Imágenes reales de los proyectos.
- Páginas internas de cada case study (acordamos enlaces externos).
