# Luna Galilea — Portfolio

Personal portfolio site built with React, TanStack Start, Tailwind CSS v4 and a
Material Design 3 token system. Tipografías Playfair Display + Open Sans e
íconos de Material Symbols, todo desde Google Fonts.

## Requisitos

- [Bun](https://bun.sh) (o npm / pnpm si preferís)
- Node 20+

## Desarrollo

```bash
bun install
bun dev
```

Abrí http://localhost:5173.

## Build de producción

```bash
bun run build
bun run start
```

## Estructura

```
src/
  assets/          imágenes (hero + mockups de proyectos)
  components/      SiteHeader, SiteFooter, Hero, FeaturedWork, ProjectCard
  routes/          file-based routing (TanStack Router)
    index.tsx      landing
    about.tsx
    contact.tsx
    __root.tsx     layout + fuentes + SEO
  styles.css       design tokens MD3 + Tailwind v4
```

## Subir a GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin git@github.com:<usuario>/<repo>.git
git push -u origin main
```

## Pendientes

- Reemplazar los `href="#"` de los case studies por las URLs reales.
- Cambiar las imágenes de `src/assets/smart-*.jpg` y `hub-android.jpg` por los mockups reales.
- Añadir tema oscuro cuando esté el `Dark.tokens.json`.